import random
ran=random.randint(0,10)
print(ran)
i=0

while(i==0):

    y=int(input("Enter the input"))
    if(ran>y):
        print ('think a bigger number')
    elif(ran<y):
        print ("Thnk of a smaller number")
    elif(ran==y):
        i=1

print ("you are right")